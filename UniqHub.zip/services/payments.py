import logging
import httpx
from datetime import datetime
from typing import Optional, Tuple
from tortoise.transactions import in_transaction
import asyncio
from datetime import timedelta

from config import config
from database.models import Payment, User

logger = logging.getLogger(__name__)

class LolzPaymentSystem:
    def __init__(self):
        self.api_url = "https://api.lolz.guru"
        self.check_interval = 60  # Проверка платежей каждые 60 сек
        self.active_checks = set()

    async def create_payment(self, user_id: int, amount: float, description: str) -> Tuple[Optional[str], Optional[str]]:
        """Создание платежа"""
        try:
            headers = {"Authorization": f"Bearer {config.LOLZ_API_KEY}"}
            payload = {
                "amount": amount,
                "user_id": user_id,
                "description": description,
                "callback_url": config.LOLZ_CALLBACK_URL
            }

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.api_url}/payments",
                    json=payload,
                    headers=headers,
                    timeout=30
                )

                if response.status_code == 201:
                    data = response.json()
                    payment_id = data["id"]
                    
                    # Сохраняем платеж в БД
                    await Payment.create(
                        payment_id=payment_id,
                        user_id=user_id,
                        amount=amount,
                        currency="RUB",
                        status="pending",
                        description=description
                    )
                    
                    return data["payment_url"], None
                else:
                    error = response.json().get("error", "Unknown error")
                    return None, error

        except Exception as e:
            logger.error(f"Create payment error: {e}")
            return None, str(e)

    async def check_payment(self, payment_id: str) -> Tuple[Optional[dict], Optional[str]]:
        """Проверка статуса платежа"""
        try:
            headers = {"Authorization": f"Bearer {config.LOLZ_API_KEY}"}
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.api_url}/payments/{payment_id}",
                    headers=headers,
                    timeout=10
                )

                if response.status_code == 200:
                    return response.json(), None
                return None, response.text

        except Exception as e:
            logger.error(f"Check payment error: {e}")
            return None, str(e)

    async def get_user_balance(self, user_id: int) -> float:
        """Получение баланса пользователя"""
        user = await User.get_or_none(id=user_id)
        return user.balance if user else 0.0

    async def start_payment_checker(self):
        """Фоновая проверка платежей"""
        while True:
            await self._check_pending_payments()
            await asyncio.sleep(self.check_interval)

    async def _check_pending_payments(self):
        """Проверка неоплаченных платежей"""
        pending_payments = await Payment.filter(
            status="pending",
            created_at__gte=datetime.now() - timedelta(hours=24)
        ).limit(100)

        for payment in pending_payments:
            if payment.payment_id in self.active_checks:
                continue

            self.active_checks.add(payment.payment_id)
            try:
                payment_data, error = await self.check_payment(payment.payment_id)
                
                if payment_data and payment_data["status"] == "paid":
                    await self._process_paid_payment(payment, payment_data)
            except Exception as e:
                logger.error(f"Payment check error: {e}")
            finally:
                self.active_checks.discard(payment.payment_id)

    async def _process_paid_payment(self, payment: Payment, payment_data: dict):
        """Обработка успешного платежа"""
        async with in_transaction():
            payment.status = "paid"
            payment.paid_at = datetime.now()
            await payment.save()
            
            user = await User.get(id=payment.user_id)
            user.balance += payment.amount
            await user.save()

payment_system = LolzPaymentSystem()